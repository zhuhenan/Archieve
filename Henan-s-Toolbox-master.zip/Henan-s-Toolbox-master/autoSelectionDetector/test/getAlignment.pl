use strict;
use Bio::EnsEMBL::Registry;
use Bio::AlignIO;
use Bio::SeqIO;

################################################################################
my $registry = 'Bio::EnsEMBL::Registry';

$registry->load_registry_from_db (
	-host => 'ensembldb.ensembl.org', -user => 'anonymous'
	);

################################################################################
open(my $input, "<", "$ARGV[0]");
open(my $output_unkown,">>", "unknown.target.txt");

my (@list, %taxa, $allORpart);
while (defined($_ = <$input>)) {
	chomp $_;
	push(@list, $_);
}

if (defined($ARGV[1])) {
  open(my $input_taxa, "<", "$ARGV[1]");
  while (defined($_ = <$input_taxa>)) {
	chomp $_;
	$taxa{$_} = $_;
  }
  $allORpart = "part";
} else {
  $allORpart = "all";
}

################################################################################
my $gene_member_adaptor = $registry->get_adaptor('Multi', 'compara', 'GeneMember');
my $family_adaptor = $registry->get_adaptor('Multi','compara','Family');

foreach my $gene_name (@list) {
  
  my @species = ("human", "cow", "mouse", "dog", "horse");
  my ($gene_adaptor, $genes);
  my $index = 0;
  
  do {
	$gene_adaptor = $registry->get_adaptor($species[$index], "core", "gene");
	$genes = $gene_adaptor->fetch_all_by_external_name($gene_name);
	$index ++;
  } until (defined($genes) || $index == @species);

  if (defined($genes)) {
	foreach my $gene (@{$genes}) {
	  print $gene->stable_id,"\t",$gene->external_name,"\n";
	  my $gene_member = $gene_member_adaptor->fetch_by_stable_id($gene->stable_id);
	  if (defined($gene_member)) {
		my $families = $family_adaptor->fetch_all_by_GeneMember($gene_member);
		if (defined($families)) {
		  ###################################
		  foreach my $family (@{$families}) {
			if ($family->description_score > 0) {
			  ###################################
			  my $alignIO_aa = openOUTPUT("$gene_name-aa.fa", "fasta");
			  my $alignIO_cds = openOUTPUT("$gene_name-cds.fa", "fasta");
			  open(my $output_des, ">", "$gene_name-description.csv");
			  print $output_des "Family_ID,Family_Description,Family_Score,Ensembl_ID,Gene,Taxon_name,Taxon_common_name,Taxon_ID,Description\n";
			  ###################################
			  print "\tFamily_id: ",$family->stable_id,"\n";
			  print "\tDescription: ",$family->description,"\n";
			  print "\tDescription Score: ",$family->description_score,"\n";
			  
			  foreach my $member (@{$family->get_all_Members}) {
				printINFO($output_des, $member, $family);
			  }
			  
			  my $simple_align = $family->get_SimpleAlign;
			  print $alignIO_aa $simple_align;
			  $simple_align = $family->get_SimpleAlign(-seq_type => 'cds');
			  print $alignIO_cds $simple_align;
			  ###################################
			}
		  }
		  ###################################
		} else {
		  print "No gene familiy records exist: ",$gene_name,"\n";
		}
	  } else {
		print "GeneMember cannot be found: ",$gene_name,"\n";
	  }
	}
  } else {
	print "Unknown: ",$gene_name,"\n";
  }
}

sub openOUTPUT {
  open(my $output, ">", $_[0]);
  my $alignIO = Bio::AlignIO->newFh(
	-interleaved => 0,
	-fh => $output,
	-format => $_[1]
	);
  return $alignIO;
}

sub printINFO {
  my ($output_des, $member, $family) = @_;
  print $output_des $family->stable_id,",";
  print $output_des $family->description,",";
  print $output_des $family->description_score,",";
  print $output_des $member->stable_id,",";
  if ($member->source_name =~ /Unipro/) {
	@_ = split("{", $member->description);
	@_ = split("\\(", $_[0]);
	@_ = split(",", $_[0]);
	$_ = $_[0];
	$_ =~ s/^\s+|\s+$//g;
	s/ |-/_/g;
	print $output_des $_,",";
  } elsif (!($member->source_name =~ /Unipro/) && defined($member->display_label)) {
	print $output_des $member->display_label,",";
  } elsif (!($member->source_name =~ /Unipro/)) {
	print $output_des "Ensembl_unannotated_noval_protein,";
  }
						
  print $output_des $member->taxon->name,",";
  print $output_des $member->taxon->common_name,",";
  print $output_des $member->taxon_id,",";
  print $output_des $member->description,"\n";
}