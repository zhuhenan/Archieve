use strict;

my $aa = "BST2-aa.fa";
my $cds = "BST2-cds-rename.fa";
my $aln = "BST2-aa-muscle.fa";
my $out = "BST2-cds-reorder.fa";
my (%hash, $header);

#system "muscle -in $aa -out $aln";

open(my $input, "<", $cds);
while (defined($_ = <$input>)) {
  if ($_ =~ />/) {
	s/>|\n//g;
	$header = $_;
	print "$header\n";
  } else {
	s/\n//;
	$hash{$header} .= $_;
  }
}
close $input;

open($input, "<", $aln);
open(my $output, ">", $out);
while (defined($_ = <$input>)) {
  if ($_ =~ />/) {
	print $output $_;
	s/>|\n//g;
	print $output $hash{$_},"\n";
  }
}

