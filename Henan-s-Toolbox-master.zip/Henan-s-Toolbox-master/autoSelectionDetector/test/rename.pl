use strict;

my %hash = ();
my @files = glob("*.csv");
foreach (@files) {
  print $_,"\n";
  my $accession = $1 if ($_ =~ /(\w+)-description/);
  
  open(my $input_des, "<", "$accession-description.csv");
  open(my $input_aa, "<", "$accession-aa.fa");
  open(my $input_cds, "<", "$accession-cds.fa");
  open(my $output_aa, ">", "$accession-aa-rename.fa");
  open(my $output_cds, ">", "$accession-cds-rename.fa"); 

  undef %hash;
  $_ = <$input_des>;
  while (defined($_ = <$input_des>)) {
	@_ = split(",", $_);
	$_ = "$_[4].$_[3]";
	s/ |-|_/./g;
	s/'|"//g;
	$_ = "$_[5]_$_";
	s/ |-/_/g;
	$hash{$_[3]} = $_;
	print "$_[3] => $hash{$_[3]}\n";
  }
  close $input_des;
  
  printSequence($input_aa, \%hash, $output_aa);
  printSequence($input_cds, \%hash, $output_cds);
}

sub printSequence {
  my $input = $_[0];
  my %hash = %{$_[1]};
  my $output = $_[2];
  while (defined($_ = <$input>)) {
	if ($_ =~ />/) {
	  s/>//;
	  @_ = split("\/", $_);
	  print $output ">$hash{$_[0]}\n";
	} else {
	  print $output $_;
	}
  } 
}