use strict;
use Bio::EnsEMBL::Registry;
use Bio::AlignIO;
use Bio::SeqIO;

## Load the registry automatically
my $registry = 'Bio::EnsEMBL::Registry';

$registry->load_registry_from_db (
	-host => 'ensembldb.ensembl.org', -user => 'anonymous'
	);

## Load the input file and target gene name
open(my $input, "<", "$ARGV[0]");
open(my $output_unkown,">>", "unknown.target.txt");

my (%list);
while (defined($_ = <$input>)) {
	chomp $_;
	@_ = split("\t", $_);
	$list{$_[0]} = $_[1];
}

## Get adaptors for further analysis
my $gene_member_adaptor = $registry->get_adaptor('Multi', 'compara', 'GeneMember');
my $gene_tree_adaptor = $registry->get_adaptor('Multi','compara','GeneTree');
my $gene_adaptor;

##
while (my ($geneName, $geneTaxa) = each %list) {
  
  $gene_adaptor = $registry->get_adaptor($geneTaxa, 'core', 'gene');
  my $genes = $gene_adaptor->fetch_all_by_external_name($geneName);
  
  foreach my $gene (@$genes) {
	my $member = $gene_member_adaptor->fetch_by_stable_id($gene->stable_id);
	die "no members" unless (defined $member);
	
	# Fetch the tree
	my $geneTree = $gene_tree_adaptor->fetch_all_by_Member($member)->[0];

	# Get the protein multialignment and the back-translated CDS alignment
	my $alignIO_aa = openOUTPUT("$geneName-aa.fa", "fasta");
	my $alignIO_cds = openOUTPUT("$geneName-cds.fa", "fasta");
	print $alignIO_aa $geneTree->get_SimpleAlign;
	print $alignIO_cds $geneTree->get_SimpleAlign(-seq_type => 'cds');
	
	# Print description file
	printInfo($geneTree, $geneName);
  }
}

sub openOUTPUT {
  open(my $output, ">", $_[0]);
  my $alignIO = Bio::AlignIO->newFh(
	-interleaved => 0,
	-fh => $output,
	-format => $_[1]
	);
  return $alignIO;
}

sub printInfo {
  my $geneTree = $_[0];
  my $geneName = $_[1];
  my @leaves = @{$geneTree->get_all_leaves};
  
  open(my $output_des, ">", "$geneName-description.csv");
  print $output_des "Gene_Name,Gene_Tree_ID,Ensembl_ID,Gene,Taxon_name,Taxon_common_name,Taxon_ID,Description\n";
  foreach my $leaf (@leaves) {
	print $output_des $geneName,",";
	print $output_des $geneTree->stable_id,",";
	print $output_des $leaf->stable_id,",";
	if (!(defined($leaf->display_label))) {
	  print $output_des "Ensembl_unannotated_gene,";
	} else {
	  print $output_des $leaf->display_label,",";
	}
	print $output_des $leaf->taxon->name,",";
	print $output_des $leaf->taxon->common_name,",";
	print $output_des $leaf->taxon_id,",";
	print $output_des $leaf->description,"\n";
  }
}