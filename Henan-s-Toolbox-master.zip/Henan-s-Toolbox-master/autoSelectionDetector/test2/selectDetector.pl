use strict;
use File::Copy qw(copy);

my (@files, $tree_name, $tree_file, $troplogy);
my ($ctl_file, $result_path);
my ($file_aa, $file_aa_aln);
my ($file_cds, $file_cds_aln, $file_cds_phylip);
my ($input, $output);
my $mafft_path = "mafft";
my $pal2nal_path = "pal2nal.v14/pal2nal.pl";
my $raxml_path = "raxmlHPC-PTHREADS";
my $paml_path = "codeml";

@files = glob("*-aa.fa");
foreach $_ (@files) {
    
    # Amino acid sequence file
    $file_aa = $_;
    # CDS sequence file
    s/aa/cds/;
    $file_cds = $_;
    # CDS alignment file
    s/cds/cds-aln/;
    $file_cds_aln = $_;
    # Amino acid alignment file
    s/cds/aa/;
    $file_aa_aln = $_;
    # CDS alignment in the phylip format
    s/aa-aln\.fa/cds-aln\.phylip/;
    $file_cds_phylip = $_;
    # Gene name
    s/-cds-aln\.phylip//;
    $tree_name = $_;
    # Generate files that PAML required
    $tree_file = "RAxML_bestTree.$tree_name";
    $troplogy = "$tree_name-troplogy.tree";
    $ctl_file = "$tree_name.ctl";
    $result_path = "$tree_name-paml";
    
    # Align amino acid sequences
    system "$mafft_path --auto --thread 2 $file_aa > $file_aa_aln";
    
    # Align CDS sequences according to the amino acid alignment
    system "perl $pal2nal_path -output fasta $file_aa_aln $file_cds > $file_cds_aln";
    
    # Convert fasta format to phylip format
    fasta2phylip($file_cds_aln, $file_cds_phylip);
    
    # Reconstruct phylogenetic tree through RAxML
    system "$raxml_path -f a -s $file_cds_phylip -m GTRCAT -# 10 -n $tree_name -x 123456 -p 12345 -T 2";
    
    # Clean bootstrap support and branch length
    generateTroplogy($tree_file, $troplogy);
    
    # Generate PAML control file
    generateCtl($file_cds_phylip, $troplogy, $ctl_file, $result_path, $tree_name);
    
    #
    system "$paml_path $result_path/$ctl_file";
    
    # Report the best fit model
    selectBestModel("$result_path/rst");
}

sub fasta2phylip {
    my ($input, $output, %hash, $header, $num, $len);
    open($input, "<", $_[0]);
    open($output, ">", $_[1]);
    
    while (defined($_ = <$input>)) {
        chomp $_;
        if ($_ =~ />/) {
            s/>//;
            @_ = split("\/", $_);
            $header = substr($_[0], 0, 30);
        } else {
            $hash{$header} .= $_;
        }
    }
    close $input;
    
    $num = keys %hash;
    $len = length($hash{(sort keys %hash)[-1]});
    print $output " $num $len\n";
    while (my ($key, $value) = each %hash) {
        print $output "$key  $value\n";
    }
    close $output;   
}

sub generateTroplogy {
    my ($input, $output);
    open($input, "<", $_[0]);
    open($output, ">", $_[1]);
    
    while (defined($_ = <$input>)) {
        s/:0.(\w+)|:1.(\w+)|:0.0//g;
        print $output $_;
    }
    close $input;
    close $output;
}

sub generateCtl {
    my ($file_cds_phylip, $troplogy, $ctl_file, $result_path, $tree_name) = @_;
    mkdir $result_path;
    copy($file_cds_phylip,"$result_path/$file_cds_phylip");
    copy($troplogy, "$result_path/$troplogy");
    
    open(my $output, ">", "$result_path/$tree_name.ctl");
    print $output "seqfile = $result_path/$file_cds_phylip\n";
    print $output "treefile = $result_path/$troplogy\n";
    print $output "outfile = $result_path/$tree_name.paml\n";
    print $output "noisy = 9\n";
    print $output "verbose = 1\n";
    print $output "runmode = 0\n";
    print $output "seqtype = 1\n";
    print $output "CodonFreq = 2\n";
    print $output "clock = 0\n";
    print $output "aaDist = 0\n";
    print $output "aaRatefile = dat/jones.dat\n";
    print $output "model = 0\n";
    print $output "NSsites = 1 2\n";
    print $output "icode = 0\n";
    print $output "Mgene = 0\n";
    print $output "fix_kappa = 0\nkappa = 2\n";
    print $output "fix_omega = 0\nomega = .4\n";
    print $output "fix_alpha = 1\nalpha = 0.\n";
    print $output "Malpha = 0\n";
    print $output "ncatG = 8\n";
    print $output "getSE = 0\n";
    print $output "RateAncestor = 1\n";
    print $output "Small_Diff = .5e-6\n";
    print $output "cleandata = 1\n";
    print $output "method = 0\n";
}

sub selectBestModel {
    my @lnls = ();
    open(my $input, "<", $_[0]);
    while (defined($_ = <$input>)) {
        if ($_ =~ /lnL =/) {
            s/ |\n|lnL =//g;
            push(@lnls, $_);
        }
    }
    close $input;
    
    my $d = ($lnls[0] - $lnls[1])/-2;
    if ($d > 5.99) {
        print "$d Model 2: negative + neutral + positive\n";
    } else {
        print "$d Model 1: negative + neutral\n";
    }
}