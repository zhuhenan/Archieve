#!/usr/bin/perl -w
 
format HEADER =
/ ------------------------------------------------------------------------------------------------------------------\
|  treePicker.pl -f <fasta> -t <tree>                                                                               |
|                                                                                                                   |
|  Options:                                                                                                         |
|    -h    Give help screen                                                                                         |
|    -f    input fasta file                                                                                         |
|    -t    input tree file                                                                                          |
\ ------------------------------------------------------------------------------------------------------------------/
.

use strict;
use warnings;

# ------------------------------------------------------------------------------------------------------------------
# Configuration
# ------------------------------------------------------------------------------------------------------------------
# Import local tool library
use Getopt::Long;
use Pod::Usage;

# ------------------------------------------------------------------------------------------------------------------
# Main functions
# ------------------------------------------------------------------------------------------------------------------

# Initialization
my ($opt_h, $fasta, $tree, $verbose);
my (%seq, $header, %group, %group_seq);
my $output;
	
# Get the input parameters from command line
GetOptions ("h"   => \$opt_h,
            "v"   => \$verbose,
            "f=s" => \$fasta,
			"t=s" => \$tree
);

# Call help screen or do the analysis 
if (defined $opt_h || !defined($fasta) || !defined($tree)) { &do_help; }

#
open(my $in_fasta, "<", $fasta) or die "Cannot find fasta file: $fasta";
while (defined($_ = <$in_fasta>)) {
    if ($_ =~ />/) {
        s/>|\n//g;
		$header = $_;
		$seq{$header} .= ">$header\n";
    } else {
		$seq{$header} .= $_;
	}
}
close $in_fasta;

#
open(my $in_tree, "<", $tree) or die "Cannot find tree file: $tree\n";
while (defined($_ = <$in_tree>)) {
    if ($_ =~ /taxlabels/) {
        $_ = <$in_tree>;
		do {
			#
			s/ |\t|\n|\'//g;
			#
			if ($_ =~ /\[&!/) {
                #print $_[0],"\n";
				@_ = split("\\[&!", $_);
				if ($_ =~ /color=#(\w+)/ && $_ !~ /color=#000000/) {
                    $group{$_[0]} = $1;
                } elsif ($_ =~ /color=#000000/) {
					$group{$_[0]} = "undefined";
				} else {
					$group{$_[0]} = "undefined";
				}
            } else {
				$group{$_} = "undefined";
			}
			$_ = <$in_tree>;
		} until ($_ =~ /;/);
    }
}
close $in_fasta;

#
foreach my $key (keys %seq) {
	if (exists($group{$key})) {
        $group_seq{$group{$key}} .= $seq{$key};
    } else {
		print "Missing colour code for $key\n";
	}
}

#
foreach my $color (keys %group_seq) {
	open($output, ">", "$tree.$color.fa");
	print $output $group_seq{$color};
}

# ------------------------------------------------------------------------------------------------------------------
# Sub functions
# Give help Screen and exit 
# ------------------------------------------------------------------------------------------------------------------
sub do_help {
    $~ = "HEADER";
    write;
    exit;
}

# ------------------------------------------------------------------------------------------------------------------
# Sub functions
# Clean up our mess and exit 
# ------------------------------------------------------------------------------------------------------------------
sub quit {
    my ($retcode) = @_;
    exit($retcode);
}