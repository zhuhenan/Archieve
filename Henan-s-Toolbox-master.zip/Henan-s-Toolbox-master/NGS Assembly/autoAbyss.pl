use strict;

my @files = glob("*_L001_R1_001_val_1.fq");
foreach (@files) {
	print $_;
	my $run1 = $_;
	s/_L001_R1_001_val_1/_L001_R2_001_val_2/;
	my $run2 = $_;
	@_ = split("_", $_);	
	system "abyss-pe name=$_[0] k=64 in=\'$run1 $run2\'";
}

