use strict;

my @refs = glob("../reference/influenza_all.*.fna");
my @queries = glob("*-6.fa");

foreach my $query (@queries) {
	my @name = split("\\.", $query);	
	foreach my $ref (@refs) {
		my @segs = split("\\.", $ref);
		print "blat $ref $query -t=dna -q=dna -minIdentity=70 -noHead -fastMap $name[0].$segs[3].psl\n";
		system "blat $ref $query -t=dna -q=dna -minIdentity=70 -noHead -fastMap $name[0].$segs[3].psl\n";
	}
}
