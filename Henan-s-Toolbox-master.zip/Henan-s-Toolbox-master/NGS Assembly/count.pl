$_ = `find ./*/*.fna`;
@_ = split("\n", $_);
$_ = @_;
print $_/8,"\n";
