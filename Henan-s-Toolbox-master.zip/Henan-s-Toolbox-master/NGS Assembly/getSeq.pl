use strict;

my (%seq, $header);
open(my $input, "<", "../../reference/influenza.fna");
while (defined($_ = <$input>)) {
	if ($_ =~ />/) {
		@_ = split("\\|", $_);
		$header = $_[3];
	} else {
		chomp $_;
		$seq{$header} .= $_;
	}
}

my $output;
my @files = glob("*.sum.txt");
foreach (@files) {
	open($input, "<", $_);
	s/sum\.txt/ref\.fna/;
	open(my $output, ">", $_);

	$_ = <$input>;
	@_ = split("\t", $_);
	@_ = split("_", $_[0]);
	print $_[0],"\n";
	print $output ">$_[0]\n$seq{$_[0]}\n";
}
