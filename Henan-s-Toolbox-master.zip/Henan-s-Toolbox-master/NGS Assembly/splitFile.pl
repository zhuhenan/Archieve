use strict;

my (%index, %sequence);
my @seg = ('','PB2','PB1','PA','HA','NP','NA','MP','NS');

open(my $input, "<", "influenza_na.dat");
while (defined($_ = <$input>)) {
	chomp $_;
	@_ = split("\t");
	if ($_[-1] =~ /c/) {
		#print $_[0],"\n";
		$index{$_[0]} = $_;
	}
}
close $input;

my $header;
open($input, "<", "influenza.fna");
while (defined($_ = <$input>)) {
	if ($_ =~ />/) {
		@_ = split("\\|", $_);
		$header = $_[3];
		#print $header,"\n";
	} else {
		chomp $_;
		$sequence{$header} .= $_;
	}
}
close $input;

my $output;
while (my ($key, $value) = each %sequence) {
	print $key,"\n";
	if (exists($index{$key})) {
		#print $key,"\n";
		@_ = split("\t", $index{$key});
		#print $_[2],"\n";
		open($output, ">>", "influenza_all.$seg[$_[2]].fna");
		$header = ">$_[0]_$_[1]_$_[3]_$_[4]_$_[5]\n";
		print $output $header;
		print $output $value,"\n";
	} else {
		#print "\n";
	}
}
