use strict;

my @files = glob("*.fna");
foreach (@files) {
	print $_,"\n";
	system "samtools faidx $_";
}
