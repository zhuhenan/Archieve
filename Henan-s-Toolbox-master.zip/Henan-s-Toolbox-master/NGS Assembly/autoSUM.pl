use strict;

my %hash;
my @files = glob("*.psl");
foreach (@files) {
	open(my $input, "<", $_);
	s/psl/sum.txt/;
	open(my $output, ">", $_);

	undef %hash;
	while (defined($_ = <$input>)) {
		if ($_ =~ /_/) {
			@_ = split("\t", $_);
			$hash{$_[13]} ++;
		}
	}
	close $input;

	foreach my $key (sort {$hash{$b} <=> $hash{$a}} keys %hash) {
		print $output "$key\t$hash{$key}\n";
	}
}
