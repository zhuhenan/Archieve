use strict;
use warnings;

use FindBin;
use File::Spec;
use lib File::Spec->catdir($FindBin::Bin, '.', 'script');
use script::target;

my (%allTargets, $best_score, $best_ref, $best_key);
my (%seq, $header, $input);
open($input, "<", "../reference/influenza.fna");
while (defined($_ = <$input>)) {
	if ($_ =~ />/) {
		@_ = split("\\|", $_);
		$header = $_[3];
	} else {
		chomp $_;
		$seq{$header} .= $_;
	}
}
close $input;

open(my $output_sum, ">", "ref_summary.csv");
print $output_sum "File,Ref,Coverage,Score\n";

my @files = glob("*.psl");
foreach (@files) {
    
    undef %allTargets;
    print $_,"\n";
    open($input, "<", $_);
    print $output_sum $_,",";
    
    s/psl/ref\.fna/;
    open(my $output_fa, ">", $_);
    
    while (defined($_ = <$input>)) {
        @_ = split("\t", $_);
        if (!(exists($allTargets{$_[13]}))) {
            $allTargets{$_[13]} = script::target->new($_[13], $_[15], $_[16], $_[14]);
        } else {
            $allTargets{$_[13]}->update($_[15], $_[16]);
        }
    }
    close $input;
    
    $best_score = 0;
    foreach (keys %allTargets) {
        #print $allTargets{$_}->score,"\n";
        if ($allTargets{$_}->score > $best_score) {
            $best_key = $_;
            $best_ref = $allTargets{$_};
            $best_score = $allTargets{$_}->score;
        }
    }
    
    
    print $output_sum $best_ref->getName,",",$best_ref->getCoverage,",";
    print $output_sum $best_ref->score,"\n";
    
    @_ = split("_", $best_key);
    print $output_fa ">$best_key\n$seq{$_[0]}\n";
}
