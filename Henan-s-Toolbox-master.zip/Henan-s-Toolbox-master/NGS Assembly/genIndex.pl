use strict;

my @files = glob("*.cons.fna");
foreach (@files) {
	print $_,"\n";
	system "bowtie2-build $_ $_";
}
