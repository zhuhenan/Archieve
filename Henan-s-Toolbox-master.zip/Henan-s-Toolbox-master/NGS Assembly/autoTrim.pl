use strict;

my @files = glob("*_L001_R1_001.fastq");
foreach (@files) {
	my $r1 = $_;
	s/R1/R2/;
	my $r2 = $_;
	system "trim_galore -q 30 --paired --length 80 $r1 $r2";
}
