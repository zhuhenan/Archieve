use strict;

my @files = glob("*.sam");
foreach (@files) {
	my $sam = $_;
	s/sam/bam/;
	my $bam  = $_;
	s/\.bam//;
	my $name = $_;
	
	@_ = split("\\.", $_);
	my $ref = "ref/$_[0]-6.$_[1].ref.fna";
	my $cons_fq = "$_[0].$_[1].cons.fq";
	my $cons_fa = "$_[0].$_[1].cons.fna";

	system "samtools view -S $sam -b -o $bam";
	system "samtools sort $bam $name";
	system "samtools index $bam";
	system "samtools mpileup -E -uf $ref $bam | bcftools view -cg - | vcfutils.pl vcf2fq > $cons_fq";
	system "seqret -osformat fasta $cons_fq -out2 $cons_fa";
}
