use strict;

my @files = glob("*.fa");
foreach (@files) {
	print $_,"\n";
	system "makeblastdb -parse_seqids -hash_index -in $_ -dbtype nucl -out $_";
}
