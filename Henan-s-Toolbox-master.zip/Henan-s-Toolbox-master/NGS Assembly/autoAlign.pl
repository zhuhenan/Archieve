use strict;

my @segs = ("PB2","PB1","PA","HA","NP","NA","MP","NS");
my @files = glob("*_L001_R1_001_val_1.fq");
foreach (@files) {
	print "run1: ",$_,"\n";
	my $run1 = $_;
	s/_L001_R1_001_val_1/_L001_R2_001_val_2/;
	print "run2: ",$_,"\n";
	my $run2 = $_;
	@_ = split("_", $_);
	my $header = $_[0];
	print "ref: $_\n";
	
	foreach my $seg (@segs) {
		my $ref = "./ref/$header-6.$seg.ref.fna";
		my $output = "$header.$seg.sam";
		print "bowtie2 -p 6 -x $ref -1 $run1 -2 $run2 -S $output\n";
		system "bowtie2 -p 6 -x $ref -1 $run1 -2 $run2 -S $output";
	}
	
}
