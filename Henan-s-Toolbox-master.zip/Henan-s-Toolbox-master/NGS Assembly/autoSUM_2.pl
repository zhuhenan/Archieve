use strict;

$_ = `find ./*/*.sam`;
my @files = split("\n", $_);
my %hash;
foreach (@files) {
	my $sam = $_;
	print $_,"\n";
	@_ = split("\/", $_);
	my $label = $_[1];
	@_ = split("\\.", $_[-1]);
	my $num = &seg2num($_[1]);
	$_ = `SAM_STATS $sam`;
	@_ = split("\t", $_);
	$_ = $_[2];
	s/Coverage:|%//g;
	$hash{$label}[$num] = $_;
	print "$label => $num => ",$hash{$label}[$num],"\n";
}

open(my $output, ">", "average_coverage_summary.csv");
print $output "Sample,PB2,PB1,PA,HA,NP,NA,MP,NS\n";
foreach my $key (sort keys %hash) {
	$_ = join(",", @{$hash{$key}});
	
	print $output $key,",",$_,"\n";
}

sub seg2num {
	my $seg = shift;
	my %seg_num = (
		"PB2" => 0,
		"PB1" => 1,
		"PA" => 2,
		"HA" => 3,
		"NP" => 4,
		"NA" => 5,
		"MP" => 6,
		"NS" => 7
	);
	return $seg_num{$seg};
}
