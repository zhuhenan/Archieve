use strict;

  my (%hash, $input, $output);

my @files = glob("RAxML_bipartitions.*");
foreach my $tree (@files) {
  print $tree,"\n";
  my $seg = $1 if ($tree =~ /.([\w]+).cdna./);
  print $seg,"\n";
  
  undef %hash;
  open($input, "<", "reference_library/reference_library.pep.$seg.hash");
  while (defined($_ = <$input>)) {
	chomp $_;
	@_ = split("\t", $_);
	$hash{$_[0]} = $_;
  }
  
  my $ntaxa = scalar keys %hash;
  open($output, ">", "Equine.H3N8.$seg.tree");
  print $output "#NEXUS\nbegin taxa;\n\tdimensions ntax=$ntaxa;\n\ttaxlabels\n";
  while (my ($key, $value) = each %hash) {
	@_ = split("\t", $value);
	print $output "\t'$key'\[&Strain=\"";
	
	if ($_[0] =~ /Gaelle/) {
	  print $output $_[1],"\",Host=\"$_[2]\",Subtype=\"$_[4]\",Location=\"$_[6]\"\,!color=#ff0000]\n";
	} else {
	  print $output $_[1],"\",Host=\"$_[2]\",Subtype=\"$_[4]\",Location=\"$_[6]\"\]\n";
	}
  }
  
  print $output ";\nend;\n\nbegin trees;\ttree tree_1 = \[&R\] ";
  open($input, "<", $tree);
  $tree = <$input>;
  chomp $tree;
  print $output $tree,"\nend;";
}
